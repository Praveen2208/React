const express = require("express");
const cors = require("cors");
const fs = require('fs');
const ytdl = require('ytdl-core');
const ytsr = require('ytsr');
// const mongodb = require("mongodb").MongoClient;
// const bodyparser = require("body-parser");
const app = express();

var db;

// mongodb.connect("mongodb+srv://sk12:sk@cluster0-liljv.mongodb.net/test?retryWrites=true&w=majority", (error,dataBase)=>{
//  console.log(error);
//  db = dataBase.db("musicApp");
//  console.log("dbConnected");
// console.log(db);

// });

app.use(cors());



app.get('/search', async(req, res) => {
    console.log(req.query)
    ytsr.do_warn_deprecate = false;
    let searchData;
    var finalData;
    var finalResponse = [];
    await ytsr(req.query.search, (err, response) => {
        // res.json(response);
        searchData = response
        finalData = (searchData && searchData.items && Array.isArray(searchData.items) && searchData.items.length > 0 ? searchData.items : []).filter(item =>{
            if(item.author && item.author.verified){
                let id = item.link.slice(item.link.length - 12, item.link.length)
                return item
            }
        })
        // res.json(searchData)
        let count = 0
        for(let item = 0; item < 11; item++){
          if(finalData[item] && finalData[item].link ){
            count ++;
            ytdl.getInfo(finalData[item].link, (err, result) => {
              finalResponse.push(result)
              console.log(result)
              if(finalResponse.length == count){
                  console.log('response recieved')
                  res.json(finalResponse)
              }
            })
          }
        }
        
    })

    
//     let filter;
// function test(){
//     ytsr.getFilters('kodi aruvi', function(err, filters) {
//         if(err) throw err;
//         filter = filters.get('Type').find(o => o.name === 'Video');
//         ytsr.getFilters(filter.ref, function(err, filters) {
//           if(err) throw err;
//           res.json(filters)
//           filter = filters.get('Duration').find(o => o.name.startsWith('Short'));
//           var options = {
//             limit: 5,
//             nextpageRef: filter.ref,
//           }
//           ytsr(null, options, function(err, searchResults) {
//             if(err) throw err;
//           //   dosth(searchResults);
          
//         res.json(searchResults, filters)
//           });
//         });
//       });
// }

// test()
})


module.exports = app;